package steps;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CreateAccount_StepDefinition extends BaseClass {

	
	
	
		/**************************************************************
		 *  Method Name	: createNewAccount
		 * Description	: To Create a New Account
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@Given("Create New Account (.*) (.*) (.*)$")
		public void createNewAccount(String emailID, String firstName, String lastName) {

			String title = driver.getTitle();
			System.out.println("title-"+title);
			if (title.contains("My Shop")) {
				System.out.println("Homepage is displayed");
			} else {
				System.out.println("Homepage is not displayed");
			}
				driver.findElement(By.xpath("//a[@title=\"Log in to your customer account\"]")).click();
				String authentication =driver.findElement(By.xpath("//h1[text()=\"Authentication\"]")).getText();
				if (authentication.contains("Authentication")) {
					System.out.println("Authentication page is displayed");
				} else {
					System.out.println("Authentication page is not displayed");
				}
				

				driver.findElement(By.xpath("//input[@id=\"email_create\"]")).sendKeys(emailID);
				driver.findElement(By.xpath("//button[@id=\"SubmitCreate\"]")).click();
				
				
				driver.findElement(By.xpath("//input[@id=\"customer_firstname\"]")).sendKeys(firstName);
				driver.findElement(By.xpath("//input[@id=\"customer_lastname\"]")).sendKeys(lastName);
				String email=driver.findElement(By.xpath("//input[@id=\"email\"]")).getAttribute("value");
				if (email.contains(emailID)) {
					System.out.println("Correct email id is displayed");
				} else {
					System.out.println("Correct email id is not displayed");
				}
				driver.findElement(By.xpath("//input[@id=\"passwd\"]")).sendKeys("Test1234");
				driver.findElement(By.xpath("//button[@id=\"submitAccount\"]")).click();
				
				String successMessage=driver.findElement(By.xpath("//p[contains(text(),\"Your account has been created\")]")).getText();
				if (successMessage.contains("Your account has been created")) {
					System.out.println("Account is created successfully");
				} else {
					System.out.println("Account is not created");
				}
				
				
		}
		
		/**************************************************************
		 *  Method Name	: loginFunction
		 * Description	: To Login to the application
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@Then("Login to the application (.*)$")
		public void loginFunction(String emailID) {

			driver.findElement(By.xpath("//a[@title=\"Log in to your customer account\"]")).click();
			driver.findElement(By.xpath("//input[@id=\"email\"]")).sendKeys(emailID);
			driver.findElement(By.xpath("//input[@id=\"passwd\"]")).sendKeys("Test1234");
			driver.findElement(By.xpath("//button[@id=\"SubmitLogin\"]")).click();
			System.out.println("Login Successfull!");
		}
		
		/**************************************************************
		 *  Method Name	: logoutFunction
		 * Description	: To Logout from the application
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@Then("Logout from the application")
		public void logoutFunction() {

			driver.findElement(By.xpath("//a[@title=\"Log me out\"]")).click();
			System.out.println("Logout Successfull!");
		}
	
		
		/**************************************************************
		 *  Method Name	: tabValidation
		 * Description	: To validate the tabs in My Account page
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@And("Tab Validation")
		public void tabValidation() {
	
			String[] tabs = {"ADD MY FIRST ADDRESS","ORDER HISTORY AND DETAILS","MY CREDIT SLIPS","MY ADDRESSES","MY PERSONAL INFORMATION","testtab"};
			List<WebElement> myAccountTabs = driver.findElements(By.className("myaccount-link-list"));
			for(WebElement each:myAccountTabs)
			{
				String tabName = each.getText();
				for (int i = 0; i < tabs.length; i++) {
						if (tabName.contains(tabs[i])) {
					
						System.out.println("Tab- "+tabs[i]+" is available");
						}
						else {
							System.out.println("Tab- "+tabs[i]+" is not available");	
						}
				}
				
			}
			
			driver.findElement(By.xpath("//a[@title=\"Home\"]")).click();
		}
		
	
}
