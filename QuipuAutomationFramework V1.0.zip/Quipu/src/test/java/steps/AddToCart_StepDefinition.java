package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddToCart_StepDefinition extends BaseClass {

		/**************************************************************
		 *  Method Name	: selectProduct
		 * Description	: To Select a product from the search results
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		
		@When("Select the Product")
		public void selectProduct() {
			driver.findElement(By.xpath("//a[@title=\"Women\"]")).click();
			driver.findElement(By.xpath("//a[@title=\"Faded Short Sleeve T-shirts\"]/img")).click();

			
			driver.switchTo().frame(0);
			driver.findElement(By.xpath("//a[@name=\"Orange\"]")).click();
			WebElement dressSize = driver.findElement(By.xpath("//select[@id=\"group_1\"]"));
			Select sizeSelect = new Select(dressSize);
			sizeSelect.selectByVisibleText("S");
			String availability = driver.findElement(By.xpath("//span[@id=\"availability_value\"]")).getText();
			if(availability.contains("In stock")) {
				System.out.println("Faded Short Sleeve T-shirts - Orange, Size-S : Stock is available");
			}
			else {
				System.out.println("Faded Short Sleeve T-shirts - Orange, Size-S : Stock is not available");
			}
			
			driver.findElement(By.xpath("//a[@name=\"Blue\"]")).click();
			sizeSelect.selectByVisibleText("M");
			availability = driver.findElement(By.xpath("//span[@id=\"availability_value\"]")).getText();
			if(availability.contains("In stock")) {
				System.out.println("Faded Short Sleeve T-shirts - Blue, Size-M : Stock is available");
			}
			else {
				System.out.println("Faded Short Sleeve T-shirts - Blue, Size-M : Stock is not available");
			}


		}
		
		/**************************************************************
		 *  Method Name	: addToCart
		 * Description	: To add a product to the cart
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		
		@Then("Add to the Cart")
		public void addToCart()  {
			
			driver.findElement(By.xpath("//span[text()=\"Add to cart\"]")).click();
			
		
			String shopingCartMsg = driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/h2")).getText();
			if(shopingCartMsg.contains("Product successfully added to your shopping cart")) {
				System.out.println("Product successfully added to your shopping cart");
			} 
			else {
				System.out.println("Product is not added to your shopping cart");
			}

		}
		
		/**************************************************************
		 *  Method Name	: continueShopping
		 * Description	: To Continue shopping after adding a product to cart
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		
		@And("Continue shopping")
		public void continueShopping()  {
			
			driver.findElement(By.xpath("//span[@title=\"Continue shopping\"]")).click();
			
			driver.findElement(By.xpath("//a[@title=\"View my shopping cart\"]")).click();
			String cartTitle = driver.findElement(By.xpath("//h1[@id=\"cart_title\"]")).getText();
			System.out.println(cartTitle);
			String productQuantityText=driver.findElement(By.xpath("//span[@id=\"summary_products_quantity\"]")).getText();
		
			if(productQuantityText.contains("product")) {
				System.out.println("Product is displayed in the shopping cart");
			}
			else {
				System.out.println("Product is not displayed in the shopping cart");
			}
			
		}
}
