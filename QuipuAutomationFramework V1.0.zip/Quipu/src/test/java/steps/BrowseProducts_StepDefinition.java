package steps;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class BrowseProducts_StepDefinition extends BaseClass{

		
		/**************************************************************
		 *  Method Name	: getListOfProdutcs
		 * Description	: To Find the list of products from the search results
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@When("Find the list of products")
		public void getListOfProdutcs() {
			
			List<WebElement> homepageTabs = driver.findElements(By.xpath("//ul[contains(@class,\"menu-content\")]"));
			System.out.println("Home Page Tabs");
			System.out.println("--------------");
			for(WebElement each:homepageTabs)
			{
				String hometabName = each.getText();
				System.out.println(hometabName);
	
			}
			
			driver.findElement(By.id("search_query_top")).sendKeys("dress", Keys.ENTER);
			List<WebElement> products = driver.findElements(By.xpath("//div[@class=\"right-block\"]/h5/a[@class=\"product-name\"]"));
			int noOfproducts =products.size();
			System.out.println("No of products:"+noOfproducts);
			System.out.println("List of products:");
			System.out.println("-----------------");

			for(WebElement each:products)
			{
				String productName = each.getText();
				System.out.println(productName);
				
			}
			
			List<WebElement> productsAvailable = driver.findElements(By.xpath("//span[@class=\"available-dif\"]/preceding::div[@class=\"right-block\"]/h5/a[@class=\"product-name\"]"));

			int noOfproductsAvailable =productsAvailable.size();
			System.out.println("No of products In Stock:"+noOfproductsAvailable);
			System.out.println("List of products In Stock:");
			System.out.println("-----------------");
			for(WebElement each:productsAvailable)
			{
				String productName = each.getText();
				System.out.println(productName);
				
			}
				
		}
		
		/**************************************************************
		 *  Method Name	: getLowestPrice
		 * Description	: To Find the lowest price of product from the search results
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@And("Find the lowest price")
		public void getLowestPrice() {
			
			driver.findElement(By.id("search_query_top")).clear();
			driver.findElement(By.id("search_query_top")).sendKeys("dress", Keys.ENTER);
			List<WebElement> productPrice = driver.findElements(By.xpath("//div[@class=\"right-block\"]/div/span[@class=\"price product-price\"]"));
			List<Integer> list = new ArrayList<Integer>();
			System.out.println("List of products prices:");
			System.out.println("-----------------");
			
			for (WebElement each : productPrice) {
				String pricevalue = each.getText();
				System.out.println(pricevalue);
				String price = pricevalue.substring(1);
				if (!price.isEmpty()) {
					int salesAmt = Integer.parseInt(price);
					list.add(salesAmt);
						
				}
				
			}
			
			Collections.sort(list);
			int minVal = list.get(0);
			System.out.println("The min price is : $"+minVal);
			
				
		}
		
		
}
