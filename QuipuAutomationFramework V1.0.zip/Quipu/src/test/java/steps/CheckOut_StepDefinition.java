package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CheckOut_StepDefinition extends BaseClass {

	
	
		/**************************************************************
		 *  Method Name	: proceedToCheckOut
		 * Description	: To Check out the product from the cart
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@And("Check out the product")
		public void proceedToCheckOut() {

			driver.findElement(By.xpath("//a[@title=\"Proceed to checkout\"]")).click();
			
			//Summary Tab
			driver.findElement(By.xpath("//p/a[@title=\"Proceed to checkout\"]/span")).click();
			
			//Sign in Tab
			if(!driver.findElements(By.xpath("//input[@id=\"address1\"]")).isEmpty()) {
			driver.findElement(By.xpath("//input[@id=\"address1\"]")).sendKeys("Berliner Str 45");
			driver.findElement(By.xpath("//input[@id=\"city\"]")).sendKeys("Frankfurt");
			WebElement state = driver.findElement(By.xpath("//select[@id=\"id_state\"]"));
			Select stateSelect = new Select(state);
			stateSelect.selectByValue("1");
			driver.findElement(By.xpath("//input[@id=\"postcode\"]")).sendKeys("54321");
			driver.findElement(By.xpath("//input[@id=\"phone\"]")).sendKeys("15212245265");
			driver.findElement(By.xpath("//button[@id=\"submitAddress\"]")).click();
			}
			
			//Address Tab
			driver.findElement(By.xpath("//button[@name=\"processAddress\"]/span")).click();
			
			//Shipping Tab
			driver.findElement(By.xpath("//input[@id=\"cgv\"]")).click();
			driver.findElement(By.xpath("//button[@name=\"processCarrier\"]/span")).click();
			
			//Payment Tab
			driver.findElement(By.xpath("//a[@title=\"Pay by bank wire\"]")).click();
			//driver.findElement(By.xpath("//a[@title=\"Pay by check.\"]")).click();
			driver.findElement(By.xpath("//span[text()=\"I confirm my order\"]")).click();
			
			String orderMsg=driver.findElement(By.xpath("//p[text()=\"Your order on My Shop is complete.\"]")).getText();
			if(orderMsg.contains("Your order on My Shop is complete")) {
				System.out.println("Your order on My Shop is complete");
			}
			else {
				System.out.println("Your order on My Shop is not complete");
			}
			

		}
		 
		/**************************************************************
		 *  Method Name	: orderReference
		 * Description	: To Get the Order reference number of the product ordered
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@And("Get the Order reference number")
		public void orderReference() {
			driver.findElement(By.xpath("//a[@title=\"Go to your order history page\"]")).click();
			String orderNumber = driver.findElement(By.xpath("//tr[@class=\"first_item \"]/td[contains(@class,\"first-column\")]/a")).getText();
			System.out.println("Order reference	is : "+orderNumber);
		}
		
		/**************************************************************
		 *  Method Name	: pickProductFromCart
		 * Description	: To Pick the Product Added in the Cart
		 * Author		: Jijo Kumar	
		 * Created Date : 05-03-2024
		 * Modified Date:
		 * *************************************************************/
		@When("Pick the Product Added in the Cart")
		public void pickProductFromCart() {
			driver.findElement(By.xpath("//a[@title=\"View my shopping cart\"]")).click();
			String cartTitle = driver.findElement(By.xpath("//h1[@id=\"cart_title\"]")).getText();
			System.out.println(cartTitle);
			String productQuantityText=driver.findElement(By.xpath("//span[@id=\"summary_products_quantity\"]")).getText();
		
			if(productQuantityText.contains("product")) {
				System.out.println("Product is displayed in the shopping cart");
			}
			else {
				System.out.println("Product is not displayed in the shopping cart");
			}
		}
}
